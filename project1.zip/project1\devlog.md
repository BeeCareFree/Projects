\# Oct. 21 9:48am

For this program, I need to first figure out how to switch between interactive and batch mode (probably Boolean) using user prompt as reference.

Then I discover how to add values to history using history ID and print history to the screen. Finally, I will use the cons operator to make the ids and
history

and reverse the list before getting values. Plans might change in the future depending on what errors I find. I am using notepad to write this.



\# Oct. 21 10:03am

I am trying to use Windows PowerShell for this assignment along with notepad. This entry is just for testing purposes. No code has been started yet.



\# Oct. 21 10:29am

I believe I figured out how to get Windows PowerShell working. I copy and pasted the "mode-1.rkt" file into my project file named "expr_calc.rkt" and 
managed to get everything working. For my next session, I want to begin creating the calculator, write some initial code, and see the initial bugs of my 
code. I also swapped from notepad to nvim.



\# Oct. 21 12:30pm 

I have done some thinking on how I should approach the program. My current idea is to have a function that gets the user input, another function that 
gets the history of list of values, pasts output to current equation and defines the ids (id 1, id 2...), and a third function that outputs the values.
However, my plans might change in the future depending if I need more or less than 3 functions.

I currently have began writing the first function which gets the user input and has a few conditions that so far only allows the user to quit and displays
error. I am currently figuring out how the function should read the input values to make it read values correctly.



\# Oct. 21 1:15pm

For the first function I think I will use recursion to check each value of input if input does not say "quit" or is invalid. I believe checking the values
using additional if functions can see when I can add, subtract, multiply and divide. However, I will need to do some revisions to the code to get it
properly working and correct. For now I will end the session. However, I will be back later to fix the first function and begin implementing the second one.

Currently the project does not seem too difficult to implement. However, I am not too familier with racket, so I am spending a decent amount of time
reading the textbook to see functions and syntax.



\# Oct. 21 6:17pm

Starting a new session. I thought about the function I have implemented so far and I think it would be best to have two functions. One function begins the
calculator, reads the first line, quits if "quit" is written and calls the second function. Then I have a recursive second function that reads each value 
output and determines if it is a char, numeric, whitespace, or an error.



\# Oct. 21 7:20pm

Creating two different functions calculator and calcInput. I am looking at some of the recommended functions such as string -> list and map to 
implement into my program. I think I should create a list that holds all the elements of each line using string -> list.



\# Oct. 21 7:58pm

I have created most of functions calculator and calcInput, and I am now testing them by opening the file in DrRacket. I currently am looking at the errors 
within my code starting with a language error in the let statement in calculator. I believe I improper created the let statement so I will check.



\# Oct. 21 9:01pm

I managed to figure out fix all the syntax errors and compile-time errors within the code including improper let statements, and removing making the 
recursive statement not include and. Now I am going to attempt to program the additional lists that will store operators and numeric values.



\# Oct. 21 10:37pm

This is my second time writing this since I accidentally deleted all my work after 9:01pm. I changed my mind about writing a function that calcuates the 
expression and gets a result before I made the history output function. I created a history function that simply displays the result of the expression and
adds it to the history list.

For now I will be ending this session. My goal was not fully accomplished this session since I wanted to get done with majority of the code by the end of
today. However, I did learn a lot about racket and how all the functions are written, which is good experience. Next session I plan on starting by fixing
some of the additional problems I have encountered like the code not working after input and dealing with errors. I hope next session I can get completely
finished.



\# Oct. 22 6:05pm

For this session I hope to get finished with my project, or at least get into a state where my program works. I have had some thoughts on the project since my last session. I will try to follow the tips and create a function that evaluates a expression and yields a two element list. I also might have to 
rewrite a couple of my functions so they fit within the code. 

I hope to accomplish fixing all the bugs within my code first, then implement a function that will evaluate the equations. After those I will examine 
any issues with my code and figure out what to do next.



\# Oct. 22 6:28pm

Fixed a few syntax errors with cdr and let. I swapped the name of calcInput to applyInput. I now have a new function named calcInput. I am now going to
begin implementing the function and see how it works.



\# Oct. 22 7:21pm

Figuring out what to do with adding the results to another list. I made an operators list that holds operators and numbers list that holds numbers in
applyList. I plan on calling the calcInput function to calculate the input then I have a addToResults function that will add the input to results.



\# Oct. 22 8:13pm

I have made lots of edits to try to make a function that will add each equation provided in the input. Some of the edits include removing the 
addToResults function for now, removing the operators list and replacing it with result, allowing the applyInput function to have calls to calcInput, 
and implementing thecalcInput function with code that flags errors if needed. I have not bug fixed the code yet. Hopefully once the errors are fixed the 
code will run and calculate the correct equation with the appropriate errors output. Now I will be fixing my code once again.



\# Oct. 22 9:17pm

Update on fixing my code, I have gone ahead and made it so when elements list is empty, history is called and outputs the result. So far my code does not
work so I have to keep troubleshooting. However, I fixed the first cond statement in apply by changing it to numbersList and adding elements list to the
condition, fixed a few minor errors in calcInput and added to error statement to history if result is invalid.



\# Oct. 22 10:15pm

I decided I would be ending my session a bit earlier than I expected. I have fixed a few bugs including history being null. I removed the result parameter
from numbersList and I am trying to use numbersList to keep the result instead. I am still figuring out how the entire code is going to work and I need to
reevaluate how the code is going to work.

There are few problems I have yet to write about like how I am going to be able to get id input or find out if the program is in batch mode or interactive
mode. I did not accomplish my goal this session. I hopefully can get to a good spot by the end of next session. Today I managed to fix a lot of bugs, 
develop the calcInput function and decided on how I am going to do expressions. Next session I need to finish up my code, fix all the errors, and get my
program to work.



\# Oct. 23 10:52am

Start of session 4. In this session I hope to finish as much of the project I can and get it into a state where the code can properly solve equations. My 
goal is to get finished with the code by 6pm tonight. First I will review my code and try and figure out what needs to change, then I will figure out what
I need to do next.



\# Oct. 23 12:17pm

Still in the progress of fixing my code and testing output in my code to see if it works. I am using a simple multiplication expression to test current and
I keep receiving a "contract violation" error, so I will keep experimenting with fixing the error. The next thing I will implement the replacement of $n
with the latest result. However, I must fix my program first.



\# Oct. 23 1:03pm

I got my program to output a simple multiplication equation. Still provides an error are the input, but that is a good start. The fixes I made mostly
involved editing the condition in applyInput to give calcInput numeric numbers and not a list. Now I plan on making it so after writeHistory occurs
I can get back to the beginning calculator function.



\# Oct. 23 1:31pm

The first thing I did this commit is adding history to the calaulator parameter so I could be saved. Then, I renamed calculator to getUserInput and turned 
calculator into a new function that calls getUserInput and makes a empty history list. I also made the output look a little nicer in writeHistory and fixed
a bug in calcInput. Now I am adding a few commented functions and planning on adding a function that tests whether the code is in batch or interactive mode
next.



\# Oct. 23 2:39pm

Started adding three new functions to my program. The function testMode tests if the mode is batch or interactive. If the mode is interactive the program 
will stay thesame without the three additional functions. However, if the mode is batch the batchHistory function will be called and test whether quit has 
been called. If quit has been called the batchOutput function will be called and use a recursive loop to output the function output. For the next commit 
I will build up the batchHistory function and fix the other two functions.



\# Oct. 23 3:04pm

Got the program in a state where it works in interactive mode. I need to do further testing with batch mode. However, I will currently be moving on to
adding the printError function that will print the error code and stop the program.



\# Oct. 23 3:42pm

I implemented the printError function to print an error text when an error is present and I fixed the testMode function so quit will work. Now I am going
to attempt to create the historyValue function that will replace $n with the value under the index n in input.



\# Oct. 23 4:48pm

I created the historyValue function that takes the history, the id, numbersList and elementsList, and returns an error if history is invalid. If history is
not invalid it calls applyInput and adds the id number to numbersList. I also fixed a few errors such as calcInput conditions that were not working and
I had to fix historyValue a few times since the id was not correct. Now I will fix some more errors with the code in the applyInput and calcInput functions.

\# Oct. 23 5:33pm

ApplyInput will now provide error text if a operation is called while numbersList does not have two numbers. I decided to add a comment or two about each
function exampling what they do to make my program easier to read.

This will be the end of session 4. I will not be working on this project any further. I did not meet my goal of completely finishing my project. However,
I must turn in what I have. There is still a few problems with my code like batch not working and only simple expressions working properly. Sadly, I did
not meet my goal, but the next project I hope to finish it and get a great grade on it.
