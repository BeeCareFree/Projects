#lang Racket
; Start the function with (calculator)
;
; Andrew Shannon
(define prompt?
   (let [(args (current-command-line-arguments))]
     (cond
       [(= (vector-length args) 0) #t]
       [(string=? (vector-ref args 0) "-b") #f]
       [(string=? (vector-ref args 0) "--batch") #f]
       [else #t])))

; Initial Calculator Function
(define (calculator)
  (getUserInput '()))

; Gets the user input, turns it into a list, calls testMode if user says "quit", and calls applyInput otherwise.
(define (getUserInput history)
  (display "Enter Expression: "
    (let* [(input (read-line))
	  (elementsList (string->list input))]
     (cond
	[(string=? input "quit") (testMode history '() "y")]
	[else (applyInput (reverse elementsList) '() history)]))))

; Looks at each element in elementsList to determine if that elements is a +, -, *, \, numeric, whitespace, $, or invalid.
; Calls the appropriate function based on what value the element is.
(define (applyInput elementsList numbersList history)
  (cond
    [(null? elementsList) (testMode history numbersList "n")]
    [else
     (let [(value (car elementsList))]
       (cond
         [(char-numeric? value) (applyInput (cdr elementsList) (cons (string->number (string value)) numbersList) history)]
         [(char=? value #\$) (historyValue history (car numbersList) (cdr numbersList) (cdr elementsList))]
         [(char-whitespace? value) (applyInput (cdr elementsList) numbersList history)]
         [(null? (cdr numbersList)) (printError "Invalid Expression" history)]
         [else
           (cond
             [(char=? value #\+) (calcInput + (car numbersList) (car(cdr numbersList)) (cdr elementsList) history)] 
             [(char=? value #\-) (calcInput - (car numbersList) (car(cdr numbersList)) (cdr elementsList) history)]
             [(char=? value #\*) (calcInput * (car numbersList) (car(cdr numbersList)) (cdr elementsList) history)]
             [(char=? value #\/) (calcInput / (car numbersList) (car(cdr numbersList)) (cdr elementsList) history)]
             [else (printError "Invalid Expression" history)])]))]))

; Assigns previous a chosen previous result in history to numbersList if $ is called.
(define (historyValue history id numbersList elementsList)
  (cond
    [(null? history) (printError "Invalid Expression" history)]
    [else (applyInput elementsList (cons (list-ref history (- id 1)) numbersList) history)]))

; Prints an error if an error occurs
(define (printError errorText history)
  (display "Error: ")
  (displayln errorText)
  (getUserInput history))

; Calculates input of two values and adds them to numbersList
(define (calcInput oper value1 value2 eleList history)
    (cond
      [(and (eq? oper /) (= value2 0)) (printError "Invalid Expression" history)]
      [else
       (let [(result (oper value1 value2))]
         (applyInput eleList (cons result '()) history))]))

; Tests the program to see if it is in batch or interactive mode
(define (testMode history numbersList quitProgram)
  (cond
    [prompt?
      (cond
        [(eq? quitProgram "y") (exit)]
        [else (writeHistory history numbersList)])]
    [else (saveHistory history quitProgram)]))

; Writes the results if program is in interactive mode
(define (writeHistory history result)
  (let [(id (length history))]
    (cond
    [(null? result) (printError "Invalid Expression" history)]
    [else
     (display (+ id 1))
     (display ": ")
     (displayln (real->double-flonum (car result)))
     (getUserInput (reverse (cons (car result) history)))])))

; Saves the results if program is in batch mode
(define (saveHistory history quitProgram)
  (cond
    [(eq? quitProgram "y") (batchOutput history)]
    [(eq? quitProgram "n") (getUserInput)]))

; In batch mode, outputs all results once quit is active
(define (batchOutput history id)
  (cond
    [((null? history) (exit))]
    [else
     (display id)
     (display ": ")
     (displayln (real->double-flonum (car history)))
     (batchOutput (cdr history) (+ (id 1)))]))

